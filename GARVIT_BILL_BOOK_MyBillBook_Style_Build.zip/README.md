# GARVIT BILL BOOK — MyBillBook-style Android starter

Business: GARVIT MODULE & SMPS | Proprietor: Kanaram
Selected invoice modes: GST Tax Invoice + Non-GST Bill of Supply.

## Included now
- Android Kotlin + Jetpack Compose project
- App launcher name: GARVIT BILL BOOK
- Customer name and mobile fields
- Multiple bill line items, quantity × rate calculations
- GST switch: ON for GST invoice, OFF for non-GST bill
- GST percentage entry and total calculation
- Invoice numbering saved on this phone
- Saved item/rate catalogue
- Received amount and balance due
- PDF invoice generation to Downloads
- Android share sheet for WhatsApp and other apps
- Local invoice JSON persistence and GitHub Actions APK build workflow

## Not yet a complete MyBillBook replacement
This is a starter build, not a production-ready full billing app. Stock ledger, purchase entries, customer/supplier ledgers, full history UI, expense book, GST tax breakup (CGST/SGST/IGST), barcode, backup/restore, printer integration, logo/shop profile settings, authentication and cloud sync security are not complete. APK build and physical-device testing are still required. Do not use as a compliant tax-invoice system until GST fields/calculations are verified by an accountant.

## Build APK with GitHub Actions
1. Upload/extract all project files into the existing `GARVIT-MODULE` GitHub repository (include the hidden `.github` folder).
2. Commit the files to the default branch.
3. Open the repository's Actions tab.
4. Run or wait for workflow **Build GARVIT MODULE APK**.
5. Download artifact **GARVIT-MODULE-debug-apk** after the workflow succeeds.

Expected APK path in the build: `app/build/outputs/apk/debug/app-debug.apk`.

Build requirements: JDK 17, Android SDK 35, Android Gradle dependencies.
